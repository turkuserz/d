# 3D Card Hover Effects Showcase

This project is a minimal yet visually striking showcase of 3D card hover effects, built entirely with vanilla HTML, CSS, and JavaScript. The focus is on creating a sense of depth, realistic lighting, and smooth, subtle animations that respond to the user's cursor.

## Features

-   **Smooth 3D Rotation:** Cards tilt smoothly to follow the cursor's movement, creating an interactive 3D effect.
-   **Dynamic Shadow:** The card's shadow adjusts its position dynamically based on the rotation, simulating a realistic light source.
-   **Glass-like Shine Effect:** A subtle reflection appears on the card's surface when hovered over, enhancing the sense of depth.
-   **Minimalist & Clean Design:** The project uses a simple white-gray-black color palette, modern typography, and generous negative space for a professional look.
-   **Responsive Layout:** The card grid is fully responsive and adapts gracefully to different screen sizes, from mobile to desktop.
-   **Vanilla Stack:** Built with just HTML, CSS, and JavaScript—no libraries or frameworks needed.
-   **Performance-Optimized:** Animations are handled with `requestAnimationFrame` for a smooth and efficient user experience.

## How to View

No build step or local server is required to run this project.

1.  Clone or download this repository.
2.  Open the `index.html` file directly in your web browser.
3.  Move your cursor over the cards to see the effect.
